package com.hp.deom1.dao.tbparkingdeta;

import com.hp.deom1.pojo.Tbparkingdeta;

import java.util.List;

public interface TbtarkingdateDao {
    //新增
    int add(Tbparkingdeta tbparkingdeta);
    //查询
    List<Tbparkingdeta> tbparkingdetalist();
    //    修改上机时间
    int setupDate(Tbparkingdeta tbparkingdeta);
    //    查询时间差
    int getdate(Integer pdId);
}
