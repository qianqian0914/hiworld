package com.hp.deom1.conteroller;

import com.alibaba.fastjson.JSON;
import com.hp.deom1.pojo.Tbparking;
import com.hp.deom1.pojo.Tbparkingdeta;
import com.hp.deom1.server.tbparking.TbparkingServer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Controller
public class tbtarkingConteroller {
    @Resource
    private TbparkingServer tbparkingServer;
    @RequestMapping("/ting")
    private  String tiao(){
        return "info";
    }
    //跳转展示页面

    @RequestMapping("/add.html")
    private  String add(){
        return "login";
    }
    //添加
    @RequestMapping("/adds")
    @ResponseBody
    public  String adds(Tbparking tbparking, Tbparkingdeta tbparkingdeta){
        System.out.println("tbparking="+tbparking);
        System.out.println("tbparkingdeta="+tbparkingdeta);
        Random random=new Random();
        int i = random.nextInt(10000) + 1000000;
       tbparking.setPId(i);
        int adds = tbparkingServer.adds(tbparking);
        Map map=new HashMap();
        if (adds>0) {
            map.put("msg","成功");
        }else {
            map.put("msg","成功");
        }
        String s = JSON.toJSONString(map);
        System.out.println("json"+s);
        return s;
    }

}
