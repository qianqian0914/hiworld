package com.hp.deom1.server.tbparking;

import com.hp.deom1.dao.tbparking.TbtarkingDao;
import com.hp.deom1.dao.tbparkingdeta.TbtarkingdateDao;
import com.hp.deom1.pojo.Tbparking;
import com.hp.deom1.pojo.Tbparkingdeta;
import org.aspectj.apache.bcel.generic.TABLESWITCH;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Random;

@Service
public class TbparkingServerImpl implements TbparkingServer {
  @Resource
private TbtarkingDao tbtarkingDao;
  @Resource
  private TbtarkingdateDao tbtarkingdateDao;

    @Override
    public int adds(Tbparking tbparking) {
      int adds = tbtarkingDao.adds(tbparking);
      Tbparkingdeta tbparkingdeta=new Tbparkingdeta();
      tbparkingdeta.setPId(tbparking.getPId());
      tbparkingdeta.setPdId(new Random().nextInt(10000)+10000000);
      int add = tbtarkingdateDao.add(tbparkingdeta);
      return  add;
    }
}
