package com.hp.deom1.dao.tbparking;

import com.hp.deom1.pojo.Tbparking;

public interface TbtarkingDao {
    //添加
    int adds(Tbparking tbparking);
}
