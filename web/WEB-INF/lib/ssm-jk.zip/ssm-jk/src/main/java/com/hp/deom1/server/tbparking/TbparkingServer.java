package com.hp.deom1.server.tbparking;

import com.hp.deom1.pojo.Tbparking;

public interface TbparkingServer {
    //添加
    int adds(Tbparking tbparking);
}
