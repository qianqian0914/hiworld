package com.hp.deom1.conteroller;

import com.alibaba.fastjson.JSON;
import com.hp.deom1.pojo.Tbparkingdeta;
import com.hp.deom1.server.tbparking.TbparkingServer;
import com.hp.deom1.server.tbparkingdate.TbparkingdateServer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class tabtarkingdetaConterllor {
    @Resource
    private TbparkingdateServer tbparkingdateServer;
    @Resource
    private TbparkingServer tbparkingServer;

    //查询信息
    @RequestMapping("/query")
    @ResponseBody
    public String query() {
        List<Tbparkingdeta> tbparkingdetas = tbparkingdateServer.tbparkingdetalist();
        String string = JSON.toJSONString(tbparkingdetas);
        System.out.println("你好" + string);
        System.out.println("不好" + tbparkingdetas);
        return string;
    }

    @RequestMapping("/kaishi")
    @ResponseBody
    public String kaishi(Integer pdId) {
        System.out.println("停车开始时间:" + pdId);
        Tbparkingdeta tbparkingdeta = new Tbparkingdeta();
        tbparkingdeta.setPdId(pdId);
        tbparkingdeta.setBegin(new Date());
        int i = tbparkingdateServer.setupDate(tbparkingdeta);
        System.out.println(i);
        Map map = new HashMap();
        if (i > 0) {
            map.put("msg", "成功");
        } else {
            map.put("msg", "失败");
        }
        String string = JSON.toJSONString(map);
        System.out.println("成功=" + string);
        return string;
    }

    //停车时间
    @RequestMapping("/jieshu")
    @ResponseBody
    public String jieshu(Tbparkingdeta tbparkingdeta) {
        System.out.println("结束时间:" + tbparkingdeta);
        //调用service修改方
        //修改数据库时长网费数据字段
        int i = tbparkingdateServer.godate(tbparkingdeta);
        Map map = new HashMap();
        if (i > 0) {
            map.put("msg", "成功");
        }
        return JSON.toJSONString(map);
    }
}
