package com.hp.deom1.server.tbparkingdate;

import com.hp.deom1.dao.tbparkingdeta.TbtarkingdateDao;
import com.hp.deom1.pojo.Tbparkingdeta;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class TbparkingdateServerimpl  implements TbparkingdateServer{
   @Resource
    private TbtarkingdateDao tbtarkingdateDao;
    @Override
    public int add(Tbparkingdeta tbparkingdeta) {
        return tbtarkingdateDao.add(tbparkingdeta);
    }

    @Override
    public List<Tbparkingdeta> tbparkingdetalist() {
        return tbtarkingdateDao.tbparkingdetalist();
    }

    @Override
    public int setupDate(Tbparkingdeta tbparkingdeta) {
        return tbtarkingdateDao.setupDate(tbparkingdeta);
    }

    @Override
    public int getdate(Integer pdId) {
        return tbtarkingdateDao.getdate(pdId);
    }

    @Override
    public int godate(Tbparkingdeta tbparkingdeta) {
        tbparkingdeta.setEnd(new Date());
        tbtarkingdateDao.setupDate(tbparkingdeta);
        int getdate = tbtarkingdateDao.getdate(tbparkingdeta.getPdId());
        int sgetdate=getdate%3600!=0?getdate/3600+1:getdate/3600;
        tbparkingdeta.setPDur(sgetdate);
        float money=sgetdate*5;
        tbparkingdeta.setPCost(money);
        int i = tbtarkingdateDao.setupDate(tbparkingdeta);
        return i;
    }
}
