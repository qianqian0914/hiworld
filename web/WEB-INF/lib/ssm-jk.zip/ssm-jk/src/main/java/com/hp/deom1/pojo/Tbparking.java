package com.hp.deom1.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
//有参构造
@AllArgsConstructor
//无参构造
@NoArgsConstructor
public class Tbparking {
   private Integer pId;//int(28) unsigned NOT NULL停车编号
    private  String carNo;//varchar(28) NOT NULL汽车牌号
  private String pMark;//varchar(28) NOT NULL备注信息
}
