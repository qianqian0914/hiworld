package com.hp.deom1.pojo;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
@Data
//有参构造
@AllArgsConstructor
//无参构造
@NoArgsConstructor
public class Tbparkingdeta {
  private  Integer pdId;//int(18) unsigned NOT NULL停车详情编号
  private  Integer pId;//int、(18) unsigned NOT NULL停车单编号
  @DateTimeFormat(pattern = "yyyy-MM-dd:HH:mm:ss")
  @JSONField(format ="yyyy-MM-dd:HH:mm:ss")
   private Date begin;//datetime(6) NOT NULL停车开始时间
  @DateTimeFormat(pattern = "yyyy-MM-dd:HH:mm:ss")
  @JSONField(format ="yyyy-MM-dd:HH:mm:ss")
  private Date end;//datetime(6) NOT NULL停车结束时间
  private Integer  pDur;//int(18) NOT NULL停车时长
  private  float  pCost;//float NOT NULL停车费用
  private String pMark;
  private String carNo;
}
